#include "ps_hdf.h"

void hdf_write_int   (HDF_FILE      * hdf_file,
                      const char    * path,
                      const int       idata) {

  hdf_write_scalar (hdf_file, path, PS_INT, & idata);

  return;
}




#include <mpi.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

void exit_on_error(int ierr, const char * where) {
  if (ierr) {
    fprintf(stderr, "*** [%s] mpi error; exiting.\n", where);
    MPI_Finalize();
    exit(1);
  }
  return;
}

void print_array(const int irank, const int ivalues[], const int nvalues) {

  char buf1[8], buf2[82];
  int i;

  /* start with a string displaying the rank */
  snprintf(buf2, 82, "rank %2d:", irank);

  for (i = 0; i < nvalues; i++) {

    /* append a "," for the 2nd and later values */
    if (i > 0) {
      strncat(buf2, ", ", 82);
    }
      
    /* format the integer value */
    snprintf(buf1, 8, "%2d", ivalues[i]);

    /* append the formatted integer to the output */
    strncat(buf2, buf1, 82);
  }

  strncat(buf2, "", 82);
  puts(buf2);
  return;
}


int main(int argc, char ** argv) {

  /* data */
  int ivalues[8];

  /* loop counters */
  int i;

  /* mpi-related variables */
  int irank, isize;
  int ierr; 

  /* program start */

  /* mpi-boilerplate code */
  ierr = MPI_Init( & argc, & argv );
  exit_on_error(ierr, "MPI_Init");

  MPI_Comm_rank(MPI_COMM_WORLD, &irank);
  MPI_Comm_size(MPI_COMM_WORLD, &isize);

  /* initialize the values ONLY for rank 0 */
  if (irank == 0) {
    for (i = 0; i < 8; i++) {
      ivalues[i] = (1 + i) * (1 + i);
    }
  }

  /* broadcast the initialized values from rank 0 to the other ranks */
  ierr = MPI_Bcast(ivalues, 8, MPI_INT, 0, MPI_COMM_WORLD);
  exit_on_error(ierr, "MPI_Bcast");

  /* display what we got */
  print_array(irank, ivalues, 8);

  /* finished; clean up */
  MPI_Finalize();

  return 0;
}



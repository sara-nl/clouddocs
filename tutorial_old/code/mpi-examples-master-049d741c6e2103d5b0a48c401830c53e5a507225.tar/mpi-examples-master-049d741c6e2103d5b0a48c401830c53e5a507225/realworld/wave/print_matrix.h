
#ifndef PRINT_MATRIX_H
#define PRINT_MATRIX_H

void print_matrix(const int m, const int n, const double values[m][n]);

#endif

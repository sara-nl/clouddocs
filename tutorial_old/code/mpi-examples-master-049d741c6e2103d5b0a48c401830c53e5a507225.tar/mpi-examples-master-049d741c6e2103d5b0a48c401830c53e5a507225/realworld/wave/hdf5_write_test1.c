
#include <hdf5.h>
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char ** argv) {

  double data[5][4] = {
    { 1.0,  2.0,  3.0, 4.0},
    {-1.0,  2.0,  3.0, 4.0},
    { 1.0, -2.0,  3.0, 4.0},
    { 1.0,  2.0, -3.0, 4.0},
    { 1.0,  2.0, -3.0, 4.0},
  };

  /* file vars */
  hid_t     h5file;

  /* dataspace vars */
  const int data_rank = 2;
  hsize_t   data_dims[data_rank];  /* size definition */
  hid_t     data_h5s;              /* dataspace for the data */

  
  /* dataset vars */
  hid_t     data_h5d;     /* dataset */
  hid_t     data_h5p;     /* dataset create properties */

  /* create a new hdf5 file with default create and access properties */
  h5file = H5Fcreate("test1.h5", H5F_ACC_TRUNC, H5P_DEFAULT, H5P_DEFAULT);


  /* create a dataspace specifying the size of the data with no resizing */
  data_dims[0] = 5;
  data_dims[1] = 4;
  data_h5s = H5Screate_simple(data_rank, data_dims, NULL);


  /* create a property list for createing the dataset */
  data_h5p = H5Pcreate(H5P_DATASET_CREATE);
  
  
  /* create a dataset for storing the data */
#if H5_USE_16_API 
  data_h5d = H5Dcreate(h5file, "/data", H5T_NATIVE_DOUBLE, data_h5s,
                       data_h5p);
#else
  data_h5d = H5Dcreate(h5file, "/data", H5T_NATIVE_DOUBLE, data_h5s,
                       H5P_DEFAULT, H5P_DEFAULT, H5P_DEFAULT);

#endif
  

  /* write the data to the dataset */

  H5Dwrite(data_h5d, H5T_NATIVE_DOUBLE, H5S_ALL, H5S_ALL, H5P_DEFAULT, data);

  /* close the dataset */
  H5Dclose(data_h5d);

  /* close the property list */
  H5Pclose(data_h5p);

  /* close the dataspace for storing data */
  H5Sclose(data_h5s);

  /* close the hdf5 file */
  H5Fclose(h5file);

  return 0;
}

    

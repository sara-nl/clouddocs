
#include <stdio.h>

/* specifying r is not important; specifying c is and the wrong value
 * will give very bad results. c is used in calculating the position
 * in memory. Only the first dimension is not used. */
int sum(const int r, const int c, int values[r][c]) {

  int i, j;
  int s;

  s = 0;

  for (i = 0; i < r; i++) {
    for (j = 0; j < c; j++) {
      s += values[i][j];

      printf(" %4d", values[i][j]);
    }
    printf("\n");
  }

  return s;
}

int main(int argc, char** argv) {
  int values[12];
  int i;

  for (i = 0; i < 12; i++) {
    values[i] = i;
  }

  /* the void* suppresses all warnings */
  printf("sum = %4d\n", sum(3,4,(void*) values));
  return 0;
}

    

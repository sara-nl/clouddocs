
/*
 * Test to demonstrate the use of MPI_Type_subarray.
 */

#include <mpi.h>
#include <stdio.h>
#include "ctrain.h"

int main(int argc, char** argv) {

  /* data */

  /* each process will have a copy of this array; for the first rank, columns
   * 1 through 4 will be filled with numbers 1-12 later.
   */
  int values[3][5] = {{0,0,0,0,0},
                      {0,0,0,0,0},
                      {0,0,0,0,0}};

  /* process variables */
  int i, j;
  char buf[1024];


  /* mpi-related variables */
  int size, rank;
  MPI_Status status;

  /* create a type for sending column 4 of the matrix:
   * ndims:              2        - this is a two-dimensional matrix
   * array_of_sizes:     {3, 5}   - the size of the original matrix
   * array_of_subsizes:  {3, 1}   - the size of the edge, 3 vertical, 1 across
   * array_of_starts:    {0, 3}   - start at row 0, column 3
   */
  MPI_Datatype mpi_type_halo_send;
  int ndims_halo_send           = 2;
  int sizes_halo_send[]         = {3, 5};
  int subsizes_halo_send[]      = {3, 1};
  int starts_halo_send[]        = {0, 3};

  /* create a type for receiving data into column 1 of the matrix;
   * notice that only the array of starts is different.
   * ndims:              2        - this is a two-dimensional matrix
   * array_of_sizes:     {3, 5}   - the size of the original matrix
   * array_of_subsizes:  {3, 1}   - the size of the edge, 3 vertical, 1 across
   * array_of_starts:    {0, 0}   - start at row 0, column 0
   */
  MPI_Datatype mpi_type_halo_recv; 
  int ndims_halo_recv           = 2;
  int sizes_halo_recv[]         = {3, 5};
  int subsizes_halo_recv[]      = {3, 1};
  int starts_halo_recv[]        = {0, 0};



  /* main start */

  MPI_Init(&argc, &argv);

  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &size);

  printf("This is process %d of %d.\n", rank, size);

  /* initialize the array for the first rank, rank 0 */
  if (rank == 0)
    for (i=0; i < 3; i++)
      for (j=0; j < 4; j++)
        values[i][j] = 1 + i + 3 * j;

  /* create a type for sending the halo */
  MPI_Type_create_subarray(ndims_halo_send, sizes_halo_send,
    subsizes_halo_send, starts_halo_send, MPI_ORDER_C, MPI_INT,
    &mpi_type_halo_send);

  MPI_Type_commit(&mpi_type_halo_send);

  /* create a type for receiving the halo */
  MPI_Type_create_subarray(ndims_halo_recv, sizes_halo_recv,
    subsizes_halo_recv, starts_halo_recv, MPI_ORDER_C, MPI_INT,
    &mpi_type_halo_recv);

  MPI_Type_commit(&mpi_type_halo_recv);


  /* master only part */
  if (rank == 0) {

    /* send the data to the workers */
    for (i = 1; i < size; i++) {
      MPI_Send(values, 1, mpi_type_halo_send, i, 12345, MPI_COMM_WORLD);
    }
  }
  else {
    MPI_Recv(values, 1, mpi_type_halo_recv, MPI_ANY_SOURCE, MPI_ANY_TAG,
             MPI_COMM_WORLD, &status);

  }

  matrix_int_format(buf, 1024, 3, 5, values);

  printf("Task %d/%d:\n%s\n", rank, size, buf);
  

  MPI_Type_free(&mpi_type_halo_send);
  MPI_Type_free(&mpi_type_halo_recv);

  MPI_Finalize();

  return 0;
}



/*
 * Test to demonstrate the use of MPI_Type_contiguous.
 */

#include <mpi.h>
#include <stdio.h>
#include "helpers.h"

int main(int argc, char** argv) {

  int size, rank;


  MPI_Datatype halo_east, halo_west; 

  MPI_Status status;


  /* Each process has a computational domain of a 3 x 5 matrix and a 
  /* each process will have its own copy of this array */
  int my_data[3][;
  
  int i;

  char s[1024];

  /* main start */

  MPI_Init(&argc, &argv);

  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
  MPI_Comm_size(MPI_COMM_WORLD, &size);

  printf("This is process %d of %d.\n", rank, size);

  /* create a type for an array of 10 ints */
  MPI_Type_contiguous(10, MPI_INT, &mpi_type_array10);
  MPI_Type_commit(&mpi_type_array10);

  /* master only part */
  if (rank == 0) {
    for (i = 0; i < 10; i++) {
      my_data[i] = i;
    }

    /* send the data to the workers */
    for (i = 1; i < size; i++) {
      MPI_Send(my_data, 1, mpi_type_array10, i, 12345, MPI_COMM_WORLD);
    }
  }
  else {
    MPI_Recv(my_data, 1, mpi_type_array10, MPI_ANY_SOURCE, MPI_ANY_TAG,
             MPI_COMM_WORLD, &status);

    format_array(s, 1024, my_data, 10);
    printf("Task %d/%d: %s\n", rank, size, s);
  }

  

  MPI_Type_free(&mpi_type_array10);

  MPI_Finalize();

  return 0;
}


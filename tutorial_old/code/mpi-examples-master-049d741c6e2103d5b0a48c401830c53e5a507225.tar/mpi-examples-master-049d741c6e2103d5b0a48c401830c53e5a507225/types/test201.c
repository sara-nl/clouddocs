
#include <stdio.h>
#include "ctrain.h"

int main(int argc, char** argv) {

  int values1[][2] = {{11, -12}, {21, 220}, {31, -3200}};
  int values2[][3] = {{1234, 4567, 8901}, {6543, -4321, -987203}};

  char buf[2048];

  matrix_int_format(buf, 2048, 3, 2, values1);
  puts(buf);

  matrix_int_format(buf, 2048, 2, 3, values2);
  puts(buf); 

  matrix_int_format(buf, 2048, 1, 6, values1);
  puts(buf);

  return 0;
}


#ifndef _CTRAIN_H
#define _CTRAIN_H

#define MAX_LINE_LENGTH 1024

void format_array(char* dest, const int length,
                  int * array, const int count);

void matrix_int_format(
  char* dest, const int dest_length,
  const int n_rows, const int n_columns, int values[n_rows][n_columns]);

#endif

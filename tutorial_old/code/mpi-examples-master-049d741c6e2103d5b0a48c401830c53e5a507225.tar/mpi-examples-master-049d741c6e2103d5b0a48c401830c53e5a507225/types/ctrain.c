#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ctrain.h"

/* define the maximum number of characters for a formatted integer */
#define MAX_INT_CHARS 12

static inline int int_max(int i, int j) {
  return i > j ? i : j;
}

static inline int int_min(int i, int j) {
  return i < j ? i : j;
}

/* returns the length of an integer when formatted in decimal notation */
static int formatted_int_length(int ival) {

  /* length is always at least 1, because 0 needs one character too,
   * and one more if the number is negative.
   */
  int l = 2;
 
  while (ival /= 10)
    l++;

  return l;
}

static char * format_int_format(char * f, const int n, const int ival) {

  int l;

  l = formatted_int_length( ival );

  if (l >= 10) {
    snprintf(f, n, "%% %2dd", l);
  }
  else {
    snprintf(f, n, "%% %1dd", l);
  }

  return f;
}


void format_array(char* dest, const int length,
                  int * array, const int count) {
  int i;
  char s[15];

  strcpy(dest, "");

  for (i=0; i < count; i++) {
    snprintf(s, 15, "%d", array[i]);
    if (i < count - 1) {
      strcat(s, ",");
    }
    strncat(dest, s, length);
  }
  return;
}

int matrix_int_amax(
  const int n_columns, const int n_rows, int values[n_rows][n_columns]) {

  int i_amax;
  int i, j;

  i_amax = values[0][0];

  for (i = 0; i < n_rows; i++) {
    for (j = 0; j < n_columns; j++) {
      i_amax = abs( i_amax ) > abs( values[i][j] ) ? i_amax : values[i][j];
    }
  }

  return i_amax;
}

void matrix_int_format(
  char* dest, const int dest_length,
  const int n_rows, const int n_columns, int values[n_rows][n_columns]) {

  char line[MAX_LINE_LENGTH];

  /* format is "% nd" or "% nnd", where 1 < n < MAX_INT_CHARS and has 
   * one or two digits, so the format needs 3 or 4 characters, plus
   * a terminating \0. The space is reserved for an optional minus sign.
   */
  char int_format[6];

  int i_amax; /* maximum value of absolute values */

  /* a buffer for formatting integer values, plus one space, plus trailing \0 */
  char buf[MAX_INT_CHARS + 1 + 1];

  /* loop counters */
  int i, j;

  /* start */

  /* determine the value of the matrix with the largest magnitude */
  i_amax = matrix_int_amax(n_rows, n_columns, values);

  printf("i_amax = %d\n", i_amax);

  /* determine the format for formatting integers */
  format_int_format(int_format, 6, i_amax);

  printf("format is %s\n", int_format);

  /* start with an empty ouput buffer */
  strncpy(dest, "", dest_length);

  for (i=0; i < n_rows; i++) {

    /* start a new empty line */
    strncpy(line, "", MAX_LINE_LENGTH);

    for (j=0; j < n_columns; j++) {

      /* format the integer value */
      snprintf(buf, MAX_INT_CHARS, int_format, values[i][j]);

      /* add the formatted string to the destination string */
      strncat(dest, buf, dest_length);

      /* if this is not the final element, add a space */
      if ( j != n_columns - 1) {
        strncat(dest, " ", dest_length);
      }
    }
    /* add a newline */
    strncat(dest, "\n", dest_length);
  }
  return;
}

                                            

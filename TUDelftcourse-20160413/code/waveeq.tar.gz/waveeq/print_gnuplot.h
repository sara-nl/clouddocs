
#ifndef PRINT_GNUPLOT_H
#define PRINT_GNUPLOT_H

void print_gnuplot(const int m, const int n, const double values[m][n]);

#endif

#include "ps_hdf.h"

void hdf_write_double(HDF_FILE      * hdf_file,
                      const char    * path,
                      const double    ddata) {

  hdf_write_scalar (hdf_file, path, PS_DOUBLE, & ddata);

  return;
}


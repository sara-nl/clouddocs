#

This README is part of the SURFsara HPC Cloud workshop 2016.
Copyright (c) 2015-2016 SURFsara, all rights reserved

All of the material in this workshop is Open Source under the
BSD 2-Clause License: (http://opensource.org/licenses/BSD-2-Clause)

  Redistribution and use in source and binary forms, with or without modification,
  are permitted provided that the following conditions are met:
  * Redistributions of source code must retain the above copyright notice,
    this list of conditions and the following disclaimer.
  * Redistributions in binary form must reproduce the above copyright notice,
    this list of conditions and the following disclaimer in the documentation and/or
    other materials provided with the distribution.
  
  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
  IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
  INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
  LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
  OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
  OF THE POSSIBILITY OF SUCH DAMAGE.

==================================

(0)
Start a VM with 2 CPUs and a Linux distribution.
Install the gcc compiler and gnu make if needed.
Copy the example files to your VM.
Do not forget to shutdown your VM when finished.

(1)
File gridpi-serial.c contains a simple workload (calculate pi) in a simple,
serial implementation. Have a look inside the file.
Compile and run a few times.

(2)
File gridpi-mp-simple.c is a first stab at using OpenMP on gridpi-simple.c.
Have a look at the differences in the code.
Compile and run a few times, observe the difference in performance. Can you explain?

(3)
File gridpi-mp-alt.c tries to optimize on gridpi-mp-simple.c,
Have a look at the differences in the code.
Compile and run a few times, observe the difference in performance. Can you explain?

(4)
File gridpi-mp-reduction.c uses another approach to optimize on gridpi-mp-simple.c,
Have a look at the differences in the code.
Compile and run a few times, observe the difference in performance. Can you explain?

(5)
Compare the three implementations that use OpenMP again.
Any new insights?

(6)
Replace your VM with one that has more cores (use the templates|new wizard).
Play around with the parameters in the source files (e.g. POINTS_ON_AXIS).
Does the performance scale for all of the implementations? Can you explain?

-- Do not forget to shutdown your VM.

 
